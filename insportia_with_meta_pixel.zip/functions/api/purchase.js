// Cloudflare Pages Function: /api/purchase
//
// This endpoint is NOT called from the website. It's called from your own
// backend/bot when a customer actually pays for VIP or VIP+ in Telegram.
// It reports a "Purchase" event to Meta's Conversions API so ad delivery
// can optimize toward real payers, not just clicks.
//
// Because this endpoint can create ad-account-charging events, it is
// protected with a shared secret header so random requests from the
// internet cannot spam fake purchases into your Pixel.
//
// Required environment variables:
//   FB_PIXEL_ID     - your Meta Pixel ID
//   FB_CAPI_TOKEN   - your Conversions API access token
//   TRACK_SECRET    - a long random string only you and your bot know
//
// Expected POST body (JSON):
// {
//   "plan": "vip" | "vip+",
//   "click_id": "xyz123",       // the value you passed in the t.me deep link, e.g. t.me/insportia?start=xyz123
//   "fbc": "...",                // optional: fbc cookie value captured on the site before redirect, if you saved it
//   "fbp": "...",                // optional: fbp cookie value captured on the site before redirect, if you saved it
//   "email": "user@example.com", // optional, if you ever collect it
//   "external_id": "telegram_user_id" // recommended: Telegram user id as a stable identifier
// }

export async function onRequestPost(context) {
  const { request, env } = context;

  const secret = request.headers.get('X-Track-Secret');
  if (!env.TRACK_SECRET || secret !== env.TRACK_SECRET) {
    return new Response(JSON.stringify({ ok: false, error: 'unauthorized' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  let body;
  try {
    body = await request.json();
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: 'invalid_json' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  if (!body || !body.plan) {
    return new Response(JSON.stringify({ ok: false, error: 'missing_plan' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  if (!env.FB_PIXEL_ID || !env.FB_CAPI_TOKEN) {
    console.error('Missing FB_PIXEL_ID or FB_CAPI_TOKEN environment variable');
    return new Response(JSON.stringify({ ok: false, error: 'not_configured' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const value = body.plan === 'vip+' ? 29 : 19;

  const userData = {};
  if (body.fbc) userData.fbc = body.fbc;
  if (body.fbp) userData.fbp = body.fbp;
  if (body.external_id) userData.external_id = [String(body.external_id)];
  if (body.email) {
    userData.em = [await sha256Hex(body.email.trim().toLowerCase())];
  }

  const eventId = 'purchase_' + (body.click_id || Date.now()) + '_' + Date.now();

  const payload = {
    data: [
      {
        event_name: 'Purchase',
        event_id: eventId,
        event_time: Math.floor(Date.now() / 1000),
        action_source: 'system_generated', // paid via Telegram, not on the website itself
        user_data: userData,
        custom_data: {
          currency: 'USD',
          value: value,
          content_name: body.plan,
        },
      },
    ],
  };

  try {
    const fbRes = await fetch(
      `https://graph.facebook.com/v21.0/${env.FB_PIXEL_ID}/events?access_token=${env.FB_CAPI_TOKEN}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }
    );

    const fbJson = await fbRes.json().catch(() => ({}));
    if (!fbRes.ok) {
      console.error('Meta CAPI purchase error:', JSON.stringify(fbJson));
    }

    return new Response(JSON.stringify({ ok: fbRes.ok }), {
      status: fbRes.ok ? 200 : 502,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('Meta CAPI purchase request failed:', err.message);
    return new Response(JSON.stringify({ ok: false, error: 'capi_request_failed' }), {
      status: 502,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

async function sha256Hex(input) {
  const enc = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}
