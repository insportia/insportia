// Cloudflare Pages Function: /api/track
// Receives event data from the site's client-side script and forwards it
// server-side to Meta's Conversions API. The Pixel ID and access token are
// read from Cloudflare environment variables/secrets and are never exposed
// to the browser.
//
// Required environment variables (set in Cloudflare Pages dashboard ->
// Settings -> Environment variables, mark FB_CAPI_TOKEN as "Encrypt"):
//   FB_PIXEL_ID   - your Meta Pixel ID
//   FB_CAPI_TOKEN - your Conversions API access token

export async function onRequestPost(context) {
  const { request, env } = context;

  let body;
  try {
    body = await request.json();
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: 'invalid_json' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  if (!body || !body.event_name || !body.event_id) {
    return new Response(JSON.stringify({ ok: false, error: 'missing_fields' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  if (!env.FB_PIXEL_ID || !env.FB_CAPI_TOKEN) {
    // Fail quietly from the client's perspective, but report server-side
    // so it shows up in Cloudflare's function logs.
    console.error('Missing FB_PIXEL_ID or FB_CAPI_TOKEN environment variable');
    return new Response(JSON.stringify({ ok: false, error: 'not_configured' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const customData = {};
  if (body.value) {
    customData.currency = 'USD';
    customData.value = body.value;
  }
  if (body.link) {
    customData.link_clicked = body.link;
  }

  const eventTime = Math.floor(Date.now() / 1000);

  const payload = {
    data: [
      {
        event_name: body.event_name,
        event_id: body.event_id,
        event_time: eventTime,
        action_source: 'website',
        event_source_url: body.source_url || '',
        user_data: {
          client_ip_address: request.headers.get('CF-Connecting-IP') || undefined,
          client_user_agent: request.headers.get('User-Agent') || undefined,
        },
        custom_data: customData,
      },
    ],
  };

  try {
    const fbRes = await fetch(
      `https://graph.facebook.com/v21.0/${env.FB_PIXEL_ID}/events?access_token=${env.FB_CAPI_TOKEN}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }
    );

    const fbJson = await fbRes.json().catch(() => ({}));

    if (!fbRes.ok) {
      console.error('Meta CAPI error:', JSON.stringify(fbJson));
    }

    return new Response(JSON.stringify({ ok: fbRes.ok }), {
      status: fbRes.ok ? 200 : 502,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('Meta CAPI request failed:', err.message);
    return new Response(JSON.stringify({ ok: false, error: 'capi_request_failed' }), {
      status: 502,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

// Reject non-POST methods explicitly for clarity.
export async function onRequestGet() {
  return new Response(JSON.stringify({ ok: false, error: 'method_not_allowed' }), {
    status: 405,
    headers: { 'Content-Type': 'application/json' },
  });
}
