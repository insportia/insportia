# Meta Pixel + Conversions API — Setup checklist

## 0. Rotate your Conversions API token first
The token that was pasted earlier in chat is compromised. Before doing
anything else: Events Manager → your Pixel → Settings → Conversions API →
Manage Integrations → remove the old token → "Generate access token" for a
new one. Use the NEW token below, never the old one.

## 1. Create the Insportia Pixel
Events Manager → Connect Data Sources → Web → create a new Pixel for
insportia.org (don't reuse the "Villion" pixel — separate businesses should
have separate pixels).

## 2. Pixel ID — already done ✅
Pixel `1732201808432666` is already baked into all 8 HTML files
(`fbq('init', ...)` and the `<noscript>` fallback). No action needed here
unless you create a different pixel later, in which case:

```bash
grep -rl "1732201808432666" . | xargs sed -i 's/1732201808432666/YOUR_NEW_PIXEL_ID/g'
```

## 3. Set Cloudflare Pages environment variables
Cloudflare dashboard → your Pages project → Settings → Environment variables
→ add for both Production and Preview:

| Name | Value | Encrypt? |
|---|---|---|
| `FB_PIXEL_ID` | same Pixel ID as step 2 | no |
| `FB_CAPI_TOKEN` | the NEW Conversions API token from step 0 | yes |
| `TRACK_SECRET` | any long random string you generate yourself | yes |

## 4. Deploy
Push this folder to the repo Cloudflare Pages builds from (or re-upload if
you deploy manually). `functions/api/track.js` and `functions/api/purchase.js`
are auto-detected by Cloudflare Pages — no build config changes needed.

## 5. What fires automatically (no extra work)
- `PageView` — every page load
- `Lead` — clicking "Join free channel" / "Join the free channel now"
- `InitiateCheckout` (value 19) — clicking "Get VIP"
- `InitiateCheckout` (value 29) — clicking "Get VIP+"
- `Contact` — clicking "Ask us a question"

Each of these fires from both the browser (Pixel) and the server
(`/api/track` → Conversions API) with a shared `event_id`, so Meta
deduplicates them into one event instead of double-counting.

## 6. Purchase tracking (needs a bit more work — Telegram-side)
Real payments happen inside Telegram, not on the site, so Meta can't see them
automatically. To report a `Purchase` event when someone actually pays for
VIP/VIP+:

1. Change your Telegram links to carry a unique reference per visitor, e.g.
   `https://t.me/insportia?start=xyz123` instead of a bare link.
2. When your bot/manager confirms a payment for that Telegram user, call:

```bash
curl -X POST https://insportia.org/api/purchase \
  -H "Content-Type: application/json" \
  -H "X-Track-Secret: <your TRACK_SECRET>" \
  -d '{
    "plan": "vip",
    "click_id": "xyz123",
    "external_id": "<telegram_user_id>"
  }'
```

This reports a real `Purchase` event (value $19 or $29 depending on `plan`)
to Meta, which is the strongest possible signal for Meta's ad optimization —
it's worth wiring up once the click/Lead/InitiateCheckout side is confirmed
working in Test Events.

## 7. Verify everything works
Events Manager → your Pixel → Test Events → open insportia.org with the test
code appended, click around (Join, Get VIP, Get VIP+, Ask us) and confirm
each event appears with a green "Server" and "Browser" match (proves
deduplication is working, not double-counting).
